
public class Reple {
	String reple;
	
	Reple() {
		
	}
	Reple(String reple) {
		this.reple = reple;
	}
}
