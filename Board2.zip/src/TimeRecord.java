
public class TimeRecord {
	String time;
	
	TimeRecord(String time) {
		this.time = time;
	}
}
