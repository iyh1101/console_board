
public class Like {
	int like;
	
	Like() {
		
	}
	
	Like(int like) {
		this.like = like;
	}
}
